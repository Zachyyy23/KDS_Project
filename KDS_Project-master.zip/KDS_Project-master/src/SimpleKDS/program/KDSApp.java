package SimpleKDS.program;

import java.util.Scanner;

public class KDSApp {

    public static void main (String[] args) {
        Scanner input = new Scanner(System.in);
        boolean running = true;

        while (running) {
            System.out.println("KDS System");
            System.out.println("(1) View Orders");
            System.out.println("(2) Update Order Status");
            System.out.println("(3) Exit");
            System.out.println("Choose Option: ");

            int choice = input.nextInt();
            input.nextLine();

            switch (choice) {

            }
        }
    }
}
