package SimpleKDS.services;

import java.util.ArrayList;
import java.util.List;

import SimplePOS.model.Order;

public class OrderService {
    private static List<Order> orders = new ArrayList<>();
}
